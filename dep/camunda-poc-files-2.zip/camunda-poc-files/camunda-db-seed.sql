-- Run once, connected to database "camunda" as camunda_admin.
-- Same statements as postgres_seed.tf runs for IAM DB user "camunda".
DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'camunda') THEN
    CREATE ROLE "camunda" WITH LOGIN;
  END IF;
END $$;
ALTER ROLE "camunda" WITH LOGIN;
GRANT rds_iam TO "camunda";
GRANT ALL PRIVILEGES ON DATABASE "camunda" TO "camunda";
GRANT USAGE, CREATE ON SCHEMA public TO "camunda";

-- Check: should return true
SELECT pg_has_role('camunda', 'rds_iam', 'member') AS has_rds_iam;
